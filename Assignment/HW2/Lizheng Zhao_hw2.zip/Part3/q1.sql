SELECT DISTINCT BName
FROM Business B, Reviews R
WHERE B.BID = R.Business_ID;