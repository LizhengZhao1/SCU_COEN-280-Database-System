
DROP TABLE Belong;
DROP TABLE beComplimented;
DROP TABLE beFriend;
DROP TABLE Check_In;
DROP TABLE Check_Into;
DROP TABLE Comments;
DROP TABLE Operation;
DROP TABLE Business_Cat;
DROP TABLE Reviews;
DROP TABLE Business;
DROP TABLE Yelp_User;

